# AegisAI CyberShield — corrected static demo

## Files
- `index.html` — dashboard markup
- `style.css` — responsive dark cybersecurity dashboard styling
- `script.js` — browser-only demo interactions and visualizations

## Run locally
1. Extract the folder.
2. Open a terminal in this folder.
3. Run a static server (recommended):
   - Python: `python -m http.server 8000`
   - Then open `http://localhost:8000` in your browser.
4. You can also open `index.html` directly, but a local server is more representative of deployment.

## Deploy
### Netlify
Create a new site from a Git repository and set the publish directory to `aegisai-deploy` (or upload the contents of this folder using Netlify's manual deploy UI). No build command is required.

### Cloudflare Pages
Create a Pages project from your repository. Set the build command to blank and the output directory to `aegisai-deploy` (or the repository root if these files are at the root). No framework preset is needed.

### GitHub Pages
Commit these three files to a repository, enable Pages in repository settings, and select the branch/folder containing `index.html`.

## Important limitations
This is a **static frontend demonstration**, not a production cybersecurity service. Dashboard telemetry, alerts, lockdown, mitigation, threat simulation, and security checks are simulated in the browser. User registration is not persisted; there is no real authentication, backend API, database, Cloudflare firewall integration, mobile device management, or endpoint isolation. Do not use this demo to protect real systems or enter real personal information. Production deployment requires a backend, authentication, server-side authorization, persistent database, validated integrations, HTTPS, and security testing.
