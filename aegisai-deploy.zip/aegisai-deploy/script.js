/* AegisAI front-end demo interactions. This file provides browser-only simulation;
   it does not connect to a real SOC, firewall, endpoint, or authentication server. */
(() => {
  'use strict';
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const log = (message, target='#adminActivityLogConsole') => {
    const el=$(target); if(!el) return;
    const stamp=new Date().toLocaleTimeString();
    el.textContent=`[${stamp}] ${message}\n`+el.textContent;
  };
  function toast(message){let t=$('#aegisToast');if(!t){t=document.createElement('div');t.id='aegisToast';Object.assign(t.style,{position:'fixed',right:'18px',bottom:'18px',zIndex:9999,maxWidth:'min(420px,90vw)',padding:'12px 16px',background:'#103448',border:'1px solid #00aebe',borderRadius:'9px',color:'#e6faff',boxShadow:'0 8px 30px #0008'});document.body.append(t)}t.textContent=message;t.style.display='block';clearTimeout(t._timer);t._timer=setTimeout(()=>t.style.display='none',3200)}
  function setTab(id){$$('.nav-tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===id));$$('.tab-pane').forEach(p=>p.classList.toggle('active',p.id===id));}
  $$('.nav-tab').forEach(b=>b.addEventListener('click',()=>setTab(b.dataset.tab)));
  window.showUserRegistrationTab=()=>setTab('tab-user-portal');
  window.portalGoToRegistration=window.showUserRegistrationTab;
  window.portalGoToAdmin=()=>setTab('tab-admin-control');
  window.portalGoToSoc=()=>setTab('tab-soc');

  // Live canvas illustrations are illustrative only, not actual network telemetry.
  function drawCanvas(id, network=false){
    const c=document.getElementById(id); if(!c)return;
    const ctx=c.getContext('2d'); if(!ctx)return;
    const w=c.clientWidth||800,h=c.clientHeight||280,dpr=Math.min(window.devicePixelRatio||1,2);
    c.width=w*dpr;c.height=h*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);
    ctx.strokeStyle='rgba(36,93,117,.24)';ctx.lineWidth=1;
    for(let x=0;x<w;x+=32){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke()}
    for(let y=0;y<h;y+=32){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke()}
    if(network){
      const nodes=[{x:.14,y:.48,t:'EDGE'},{x:.38,y:.22,t:'AI ENGINE'},{x:.57,y:.68,t:'SOC CORE'},{x:.82,y:.35,t:'ENDPOINTS'}];
      ctx.strokeStyle='rgba(0,242,254,.36)';nodes.slice(1).forEach((n,i)=>{ctx.beginPath();ctx.moveTo(nodes[i].x*w,nodes[i].y*h);ctx.lineTo(n.x*w,n.y*h);ctx.stroke()});
      nodes.forEach((n,i)=>{ctx.beginPath();ctx.arc(n.x*w,n.y*h,10,0,Math.PI*2);ctx.fillStyle=i===2?'#10b981':'#00f2fe';ctx.shadowBlur=14;ctx.shadowColor=ctx.fillStyle;ctx.fill();ctx.shadowBlur=0;ctx.fillStyle='#c9e7f5';ctx.font='10px Inter';ctx.fillText(n.t,n.x*w-24,n.y*h+27)});
      for(let i=0;i<8;i++){let x=Math.random()*w,y=Math.random()*h;ctx.fillStyle=i%3===0?'#ff4f6d':'#10b981';ctx.globalAlpha=.7;ctx.fillRect(x,y,2,2)}ctx.globalAlpha=1;
    } else {
      ctx.strokeStyle='#00f2fe';ctx.lineWidth=2;ctx.beginPath();
      for(let x=0;x<w;x+=4){const y=h*.55+Math.sin(x*.035+Date.now()*.001)*h*.12+(Math.random()-.5)*h*.12;x===0?ctx.moveTo(x,y):ctx.lineTo(x,y)}ctx.stroke();
      ctx.strokeStyle='rgba(255,79,109,.75)';ctx.beginPath();
      for(let x=0;x<w;x+=6){const y=h*.78+Math.sin(x*.025+Date.now()*.0008)*h*.07+(Math.random()-.5)*h*.06;x===0?ctx.moveTo(x,y):ctx.lineTo(x,y)}ctx.stroke();
    }
  }
  const redraw=()=>{drawCanvas('networkVisualizerCanvas',true);drawCanvas('telemetryChartCanvas',false)};
  window.addEventListener('resize',redraw);redraw();setInterval(redraw,1800);

  const referral = $('#adminReferralLink'); if (referral) referral.textContent = `${location.href.split('#')[0].split('?')[0]}?ref=ADMIN-SUNNY-01`;

  // Counters are demo data, not live packet measurements.
  let packets=53046, uptime=0;
  setInterval(()=>{packets+=Math.floor(Math.random()*25);const p=$('#kpiPackets');if(p)p.textContent=packets.toLocaleString();uptime++;const u=$('#kpiUptime');if(u)u.textContent=[Math.floor(uptime/3600),Math.floor((uptime%3600)/60),uptime%60].map(v=>String(v).padStart(2,'0')).join(':')},2200);

  window.triggerLockdown=()=>{const b=$('#emergencyLockdownBanner');if(b)b.classList.add('active');toast('Demo lockdown banner activated. No real device was isolated.');log('DEMO: lockdown banner activated.')};
  window.releaseLockdown=()=>{const b=$('#emergencyLockdownBanner');if(b)b.classList.remove('active');toast('Demo lockdown banner released.');log('DEMO: lockdown banner released.')};
  let shield=false;const toggle=$('#autoBlockToggle');if(toggle)toggle.addEventListener('click',()=>{shield=!shield;toggle.textContent=shield?'🛡️ AUTONOMOUS SHIELD: ENABLED':'⚠️ AUTONOMOUS SHIELD: DISABLED';toggle.style.borderColor=shield?'#10b981':'';toast(`Demo autonomous shield ${shield?'enabled':'disabled'}.`)});
  window.launchSimulation=(type='ddos')=>{toast(`Safe demo simulation started: ${String(type).toUpperCase()}`);log(`DEMO simulation started: ${type}.`, '#adminAttackLogConsole');const n=$('#kpiAlerts');if(n)n.textContent=String((parseInt(n.textContent.replace(/,/g,''),10)||0)+1)};
  window.startFile1AttackSimulation=()=>{const type=$('#adminAttackTypeSelect')?.value||'General Malware';const target=$('#adminAttackTargetSelect')?.value||'demo endpoint';log(`SIMULATED ${type} event against ${target}; no external system contacted.`,'#adminAttackLogConsole');toast('Safe simulation completed. No real attack was performed.');const bar=$('#adminAttackProgressBar');if(bar){bar.style.width='100%';bar.style.transition='width .8s';setTimeout(()=>bar.style.width='0%',1800)}};
  window.runAdminSecurityCheck=()=>{log('Demo security check completed: interface responsive; no server scan was run.');toast('Demo security check completed.')};
  window.mitigateAlert=id=>{toast(`Demo mitigation recorded for ${id}. No firewall rule changed.`);log(`DEMO mitigation recorded for ${id}.`)};
  window.inspectAlert=id=>toast(`Forensic preview: ${id} (sample dashboard record).`);
  window.submitUserRegistration=()=>{const name=$('#regNameInput')?.value.trim(),email=$('#regEmailInput')?.value.trim();if(!name||!email){toast('Enter at least a name and valid email to continue.');return}const box=$('#userRegistrationResultBox');if(box){box.style.display='block';box.innerHTML='<div style="background:rgba(16,185,129,.12);border:1px solid #10b981;border-radius:8px;padding:14px;color:#a7f3d0"><strong>Demo registration recorded in this page.</strong><br>No account or backend database was created.</div>';}toast('Demo registration captured in this browser page.')};
  window.clearRegistrationForm=()=>{$$('#tab-user-portal input').forEach(i=>i.value='');$$('#tab-user-portal select').forEach(i=>i.selectedIndex=0);toast('Registration form cleared.')};
  window.findOwnRegistration=()=>toast('Lookup requires a backend database; this demo page does not store registrations.');
  window.saveOwnRegistration=()=>toast('No backend is connected; changes were not saved.');
  window.addAdministrator=()=>toast('Administrator creation requires secure backend authentication; not available in this frontend demo.');
  window.changeAdminPassword=()=>toast('Password changes require a secure backend; no password was changed.');
  window.saveAdminSupportSettings=()=>toast('Support settings are demo-only and were not persisted.');
  window.copyAdminReferral=()=>{const el=$('#adminReferralLink');if(el&&navigator.clipboard)navigator.clipboard.writeText(el.textContent).then(()=>toast('Referral text copied.')).catch(()=>toast(el.textContent));else toast(el?.textContent||'No referral link available.')};
  window.shareAdminReferral=()=>{const text=$('#adminReferralLink')?.textContent||location.href;if(navigator.share)navigator.share({title:'AegisAI referral',text}).catch(()=>{});else window.copyAdminReferral()};
  window.callSupportHotline=()=>toast('Configure a verified support phone number in a secure deployment.');
  window.emailSupportHotline=()=>{location.href='mailto:?subject='+encodeURIComponent('Cybersecurity incident report')};
  window.filterRegisteredUsers=()=>{const q=($('#userSearchInput')?.value||'').toLowerCase();$$('#registeredUsersContainer > *').forEach(el=>el.hidden=!el.textContent.toLowerCase().includes(q))};
  window.openRbacModal=()=>toast('RBAC role switching is a visual demo only; enforce roles on a backend in production.');
  window.closeRbacModal=()=>{$$('.modal,.modal-overlay').forEach(el=>el.style.display='none')};
  window.switchRbacRole=()=>toast('Role switching is not enabled in this standalone frontend.');
  window.performRbacLogin=()=>toast('Connect a real identity provider before enabling sign-in.');
  window.performRbacLogout=()=>toast('Demo logout requested.');
  window.showPublicPortal=()=>toast('Public portal preview is not connected to a public service.');
  window.closePublicPortal=()=>toast('Public portal closed.');
  window.closeEditUserModal=()=>{$$('.modal,.modal-overlay').forEach(el=>el.style.display='none')};
  window.saveUserModalEdit=()=>toast('No backend connected; user changes were not saved.');
  window.saveSettings=()=>toast('Settings are preview-only; no server settings changed.');
  window.applyCurrentPatch=()=>toast('Patch deployment requires a verified backend and authorized environment.');
  window.unblockIp=()=>toast('Firewall actions are disabled in this frontend demo.');
  window.downloadAndroidScript=()=>toast('No device-management profile is included in this demo.');
  window.downloadIosProfile=()=>toast('No mobile configuration profile is included in this demo.');
  window.globalAlertCallUser=window.callSupportHotline;
  window.globalAlertEmailUser=window.emailSupportHotline;
  window.closeGlobalAlert=()=>{$$('.global-alert,.modal-overlay').forEach(el=>el.style.display='none')};
  // Any inline onclick handlers not implemented by this demo get a safe informational response.
  const known=['addAdministrator','applyCurrentPatch','callSupportHotline','changeAdminPassword','clearRegistrationForm','closeEditUserModal','closeGlobalAlert','closePublicPortal','closeRbacModal','copyAdminReferral','downloadAndroidScript','downloadIosProfile','emailSupportHotline','filterRegisteredUsers','findOwnRegistration','globalAlertCallUser','globalAlertEmailUser','inspectAlert','launchSimulation','mitigateAlert','openRbacModal','performRbacLogin','performRbacLogout','portalGoToAdmin','portalGoToRegistration','portalGoToSoc','releaseLockdown','runAdminSecurityCheck','saveAdminSupportSettings','saveOwnRegistration','saveSettings','saveUserModalEdit','shareAdminReferral','showPublicPortal','showUserRegistrationTab','startFile1AttackSimulation','submitUserRegistration','switchRbacRole','triggerLockdown','unblockIp'];
  window.addEventListener('DOMContentLoaded',()=>{const timer=$('#monitorTimer');if(timer){let sec=300;setInterval(()=>{sec=sec>0?sec-1:300;timer.textContent=`${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`},1000)}});
})();
